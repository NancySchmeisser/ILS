﻿namespace CSHP10D_4._1
{
    partial class EineSpielerei
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonLinieFarbe = new System.Windows.Forms.Button();
            this.panelLinieFarbeVorschau = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxLinieStil = new System.Windows.Forms.ListBox();
            this.numericUpDownLinieStaerke = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonHintergrundFarbe = new System.Windows.Forms.Button();
            this.panelHintergrundFarbeVorschau = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.listBoxHintergrundMuster = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButtonHintergrundMuster = new System.Windows.Forms.RadioButton();
            this.radioButtonHintergrundFarbe = new System.Windows.Forms.RadioButton();
            this.radioButtonHintergrundOhne = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButtonLinie = new System.Windows.Forms.RadioButton();
            this.radioButtonRechteck = new System.Windows.Forms.RadioButton();
            this.radioButtonKreis = new System.Windows.Forms.RadioButton();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonBeenden = new System.Windows.Forms.Button();
            this.buttonLoeschen = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButtonAnimationAus = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownGeschw = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownWdh = new System.Windows.Forms.NumericUpDown();
            this.radioButtonAnimationAn = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLinieStaerke)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGeschw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWdh)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 300);
            this.panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonLinieFarbe);
            this.groupBox1.Controls.Add(this.panelLinieFarbeVorschau);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.listBoxLinieStil);
            this.groupBox1.Controls.Add(this.numericUpDownLinieStaerke);
            this.groupBox1.Location = new System.Drawing.Point(372, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Linie";
            // 
            // buttonLinieFarbe
            // 
            this.buttonLinieFarbe.Location = new System.Drawing.Point(147, 9);
            this.buttonLinieFarbe.Name = "buttonLinieFarbe";
            this.buttonLinieFarbe.Size = new System.Drawing.Size(43, 23);
            this.buttonLinieFarbe.TabIndex = 0;
            this.buttonLinieFarbe.Text = "...";
            this.buttonLinieFarbe.UseVisualStyleBackColor = true;
            this.buttonLinieFarbe.Click += new System.EventHandler(this.buttonLinieFarbe_Click);
            // 
            // panelLinieFarbeVorschau
            // 
            this.panelLinieFarbeVorschau.BackColor = System.Drawing.Color.Black;
            this.panelLinieFarbeVorschau.Location = new System.Drawing.Point(94, 11);
            this.panelLinieFarbeVorschau.Name = "panelLinieFarbeVorschau";
            this.panelLinieFarbeVorschau.Size = new System.Drawing.Size(47, 21);
            this.panelLinieFarbeVorschau.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Stärke";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Stil";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Farbe";
            // 
            // listBoxLinieStil
            // 
            this.listBoxLinieStil.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBoxLinieStil.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxLinieStil.FormattingEnabled = true;
            this.listBoxLinieStil.ItemHeight = 16;
            this.listBoxLinieStil.Location = new System.Drawing.Point(74, 38);
            this.listBoxLinieStil.Name = "listBoxLinieStil";
            this.listBoxLinieStil.Size = new System.Drawing.Size(120, 20);
            this.listBoxLinieStil.TabIndex = 2;
            this.listBoxLinieStil.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBoxLinieStil_DrawItem);
            // 
            // numericUpDownLinieStaerke
            // 
            this.numericUpDownLinieStaerke.Location = new System.Drawing.Point(73, 74);
            this.numericUpDownLinieStaerke.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownLinieStaerke.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownLinieStaerke.Name = "numericUpDownLinieStaerke";
            this.numericUpDownLinieStaerke.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownLinieStaerke.TabIndex = 1;
            this.numericUpDownLinieStaerke.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonHintergrundFarbe);
            this.groupBox2.Controls.Add(this.panelHintergrundFarbeVorschau);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.listBoxHintergrundMuster);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.radioButtonHintergrundMuster);
            this.groupBox2.Controls.Add(this.radioButtonHintergrundFarbe);
            this.groupBox2.Controls.Add(this.radioButtonHintergrundOhne);
            this.groupBox2.Location = new System.Drawing.Point(372, 119);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(259, 116);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hintergrund";
            // 
            // buttonHintergrundFarbe
            // 
            this.buttonHintergrundFarbe.Location = new System.Drawing.Point(147, 42);
            this.buttonHintergrundFarbe.Name = "buttonHintergrundFarbe";
            this.buttonHintergrundFarbe.Size = new System.Drawing.Size(43, 23);
            this.buttonHintergrundFarbe.TabIndex = 9;
            this.buttonHintergrundFarbe.Text = "...";
            this.buttonHintergrundFarbe.UseVisualStyleBackColor = true;
            this.buttonHintergrundFarbe.Click += new System.EventHandler(this.buttonHintergrundFarbe_Click);
            // 
            // panelHintergrundFarbeVorschau
            // 
            this.panelHintergrundFarbeVorschau.BackColor = System.Drawing.Color.Black;
            this.panelHintergrundFarbeVorschau.Location = new System.Drawing.Point(94, 42);
            this.panelHintergrundFarbeVorschau.Name = "panelHintergrundFarbeVorschau";
            this.panelHintergrundFarbeVorschau.Size = new System.Drawing.Size(47, 21);
            this.panelHintergrundFarbeVorschau.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Stil";
            // 
            // listBoxHintergrundMuster
            // 
            this.listBoxHintergrundMuster.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBoxHintergrundMuster.FormattingEnabled = true;
            this.listBoxHintergrundMuster.Location = new System.Drawing.Point(74, 69);
            this.listBoxHintergrundMuster.Name = "listBoxHintergrundMuster";
            this.listBoxHintergrundMuster.Size = new System.Drawing.Size(120, 30);
            this.listBoxHintergrundMuster.TabIndex = 5;
            this.listBoxHintergrundMuster.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBoxHintergrundMuster_DrawItem);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Farbe";
            // 
            // radioButtonHintergrundMuster
            // 
            this.radioButtonHintergrundMuster.AutoSize = true;
            this.radioButtonHintergrundMuster.Location = new System.Drawing.Point(136, 19);
            this.radioButtonHintergrundMuster.Name = "radioButtonHintergrundMuster";
            this.radioButtonHintergrundMuster.Size = new System.Drawing.Size(57, 17);
            this.radioButtonHintergrundMuster.TabIndex = 2;
            this.radioButtonHintergrundMuster.Text = "Muster";
            this.radioButtonHintergrundMuster.UseVisualStyleBackColor = true;
            // 
            // radioButtonHintergrundFarbe
            // 
            this.radioButtonHintergrundFarbe.AutoSize = true;
            this.radioButtonHintergrundFarbe.Location = new System.Drawing.Point(78, 19);
            this.radioButtonHintergrundFarbe.Name = "radioButtonHintergrundFarbe";
            this.radioButtonHintergrundFarbe.Size = new System.Drawing.Size(52, 17);
            this.radioButtonHintergrundFarbe.TabIndex = 1;
            this.radioButtonHintergrundFarbe.Text = "Farbe";
            this.radioButtonHintergrundFarbe.UseVisualStyleBackColor = true;
            // 
            // radioButtonHintergrundOhne
            // 
            this.radioButtonHintergrundOhne.AutoSize = true;
            this.radioButtonHintergrundOhne.Checked = true;
            this.radioButtonHintergrundOhne.Location = new System.Drawing.Point(23, 19);
            this.radioButtonHintergrundOhne.Name = "radioButtonHintergrundOhne";
            this.radioButtonHintergrundOhne.Size = new System.Drawing.Size(49, 17);
            this.radioButtonHintergrundOhne.TabIndex = 0;
            this.radioButtonHintergrundOhne.TabStop = true;
            this.radioButtonHintergrundOhne.Text = "ohne";
            this.radioButtonHintergrundOhne.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButtonLinie);
            this.groupBox3.Controls.Add(this.radioButtonRechteck);
            this.groupBox3.Controls.Add(this.radioButtonKreis);
            this.groupBox3.Location = new System.Drawing.Point(372, 241);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(259, 48);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Figur";
            // 
            // radioButtonLinie
            // 
            this.radioButtonLinie.AutoSize = true;
            this.radioButtonLinie.Location = new System.Drawing.Point(147, 25);
            this.radioButtonLinie.Name = "radioButtonLinie";
            this.radioButtonLinie.Size = new System.Drawing.Size(47, 17);
            this.radioButtonLinie.TabIndex = 5;
            this.radioButtonLinie.Text = "Linie";
            this.radioButtonLinie.UseVisualStyleBackColor = true;
            // 
            // radioButtonRechteck
            // 
            this.radioButtonRechteck.AutoSize = true;
            this.radioButtonRechteck.Location = new System.Drawing.Point(69, 25);
            this.radioButtonRechteck.Name = "radioButtonRechteck";
            this.radioButtonRechteck.Size = new System.Drawing.Size(72, 17);
            this.radioButtonRechteck.TabIndex = 4;
            this.radioButtonRechteck.Text = "Rechteck";
            this.radioButtonRechteck.UseVisualStyleBackColor = true;
            // 
            // radioButtonKreis
            // 
            this.radioButtonKreis.AutoSize = true;
            this.radioButtonKreis.Checked = true;
            this.radioButtonKreis.Location = new System.Drawing.Point(15, 25);
            this.radioButtonKreis.Name = "radioButtonKreis";
            this.radioButtonKreis.Size = new System.Drawing.Size(48, 17);
            this.radioButtonKreis.TabIndex = 3;
            this.radioButtonKreis.TabStop = true;
            this.radioButtonKreis.Text = "Kreis";
            this.radioButtonKreis.UseVisualStyleBackColor = true;
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(372, 295);
            this.trackBar1.Maximum = 3;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(200, 45);
            this.trackBar1.TabIndex = 4;
            this.trackBar1.Value = 2;
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(392, 484);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(68, 23);
            this.buttonStart.TabIndex = 5;
            this.buttonStart.Text = "Los geht´s";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonBeenden
            // 
            this.buttonBeenden.Location = new System.Drawing.Point(540, 484);
            this.buttonBeenden.Name = "buttonBeenden";
            this.buttonBeenden.Size = new System.Drawing.Size(68, 23);
            this.buttonBeenden.TabIndex = 6;
            this.buttonBeenden.Text = "Beenden";
            this.buttonBeenden.UseVisualStyleBackColor = true;
            this.buttonBeenden.Click += new System.EventHandler(this.buttonBeenden_Click);
            // 
            // buttonLoeschen
            // 
            this.buttonLoeschen.Location = new System.Drawing.Point(466, 484);
            this.buttonLoeschen.Name = "buttonLoeschen";
            this.buttonLoeschen.Size = new System.Drawing.Size(68, 23);
            this.buttonLoeschen.TabIndex = 7;
            this.buttonLoeschen.Text = "Löschen";
            this.buttonLoeschen.UseVisualStyleBackColor = true;
            this.buttonLoeschen.Click += new System.EventHandler(this.buttonLoeschen_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButtonAnimationAus);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.numericUpDownGeschw);
            this.groupBox4.Controls.Add(this.numericUpDownWdh);
            this.groupBox4.Controls.Add(this.radioButtonAnimationAn);
            this.groupBox4.Location = new System.Drawing.Point(372, 329);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(259, 131);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Animation";
            // 
            // radioButtonAnimationAus
            // 
            this.radioButtonAnimationAus.AutoSize = true;
            this.radioButtonAnimationAus.Location = new System.Drawing.Point(78, 19);
            this.radioButtonAnimationAus.Name = "radioButtonAnimationAus";
            this.radioButtonAnimationAus.Size = new System.Drawing.Size(43, 17);
            this.radioButtonAnimationAus.TabIndex = 9;
            this.radioButtonAnimationAus.Text = "Aus";
            this.radioButtonAnimationAus.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Geschwindigkeit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Anzahl Wiederholungen";
            // 
            // numericUpDownGeschw
            // 
            this.numericUpDownGeschw.Location = new System.Drawing.Point(133, 78);
            this.numericUpDownGeschw.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownGeschw.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownGeschw.Name = "numericUpDownGeschw";
            this.numericUpDownGeschw.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownGeschw.TabIndex = 6;
            this.numericUpDownGeschw.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericUpDownWdh
            // 
            this.numericUpDownWdh.Location = new System.Drawing.Point(133, 47);
            this.numericUpDownWdh.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownWdh.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWdh.Name = "numericUpDownWdh";
            this.numericUpDownWdh.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownWdh.TabIndex = 5;
            this.numericUpDownWdh.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // radioButtonAnimationAn
            // 
            this.radioButtonAnimationAn.AutoSize = true;
            this.radioButtonAnimationAn.Checked = true;
            this.radioButtonAnimationAn.Location = new System.Drawing.Point(15, 19);
            this.radioButtonAnimationAn.Name = "radioButtonAnimationAn";
            this.radioButtonAnimationAn.Size = new System.Drawing.Size(38, 17);
            this.radioButtonAnimationAn.TabIndex = 4;
            this.radioButtonAnimationAn.TabStop = true;
            this.radioButtonAnimationAn.Text = "An";
            this.radioButtonAnimationAn.UseVisualStyleBackColor = true;
            // 
            // EineSpielerei
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 540);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.buttonLoeschen);
            this.Controls.Add(this.buttonBeenden);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "EineSpielerei";
            this.Text = "    ";
            this.Load += new System.EventHandler(this.EineSpielerei_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLinieStaerke)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGeschw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWdh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBoxLinieStil;
        private System.Windows.Forms.NumericUpDown numericUpDownLinieStaerke;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButtonHintergrundMuster;
        private System.Windows.Forms.RadioButton radioButtonHintergrundFarbe;
        private System.Windows.Forms.RadioButton radioButtonHintergrundOhne;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBoxHintergrundMuster;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButtonLinie;
        private System.Windows.Forms.RadioButton radioButtonRechteck;
        private System.Windows.Forms.RadioButton radioButtonKreis;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonBeenden;
        private System.Windows.Forms.Button buttonLoeschen;
        private System.Windows.Forms.Panel panelLinieFarbeVorschau;
        private System.Windows.Forms.Button buttonLinieFarbe;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button buttonHintergrundFarbe;
        private System.Windows.Forms.Panel panelHintergrundFarbeVorschau;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownGeschw;
        private System.Windows.Forms.NumericUpDown numericUpDownWdh;
        private System.Windows.Forms.RadioButton radioButtonAnimationAn;
        private System.Windows.Forms.RadioButton radioButtonAnimationAus;
    }
}

